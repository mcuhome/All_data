#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f10x.h"

void SysTick_Init(void);
void SysTick_Handler(void);
// void assignment1(void);
// void assignment2(void);
// void assignment3(void);



#endif /* __SYSTICK_H */
