#ifndef _TIME_H_
#define _TIME_H_

#include "stm32f0xx.h"

void TIM1_PWM_Config(void);
void TIM3_PWM_Config(void);
void TIM3_Config(void);
void TIM6_Config(void);
void TIM14_Config(void);




#endif  /* _TIME_H_ */


