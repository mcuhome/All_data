var group___c_m_s_i_s___r_t_o_s___kernel_ctrl =
[
    [ "osCMSIS", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga702196bacccbb978620c736b209387f1", null ],
    [ "osCMSIS_KERNEL", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#gab78dce646fabec479c5f34bc5175b7de", null ],
    [ "osFeature_MainThread", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga22f7d235bc9f783933bd5a981fd79696", null ],
    [ "osFeature_SysTick", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#gae554ec16c23c5b7d65affade2a351891", null ],
    [ "osKernelSystemId", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga47cf03658f01cdffca688e9096b58289", null ],
    [ "osKernelSysTickFrequency", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga9e0954d52722673e2031233a2ab99960", null ],
    [ "osKernelSysTickMicroSec", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#gae12c190af42d7310d8006d64f4ed5a88", null ],
    [ "osKernelInitialize", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga53d078a801022e202e8115c083ece68e", null ],
    [ "osKernelRunning", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga3b571de44cd3094c643247a7397f86b5", null ],
    [ "osKernelStart", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#gaab668ffd2ea76bb0a77ab0ab385eaef2", null ],
    [ "osKernelSysTick", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#gad0262e4688e95d1e9038afd9bcc16001", null ]
];